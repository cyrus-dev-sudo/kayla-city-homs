'use client'

import { UserRole, ROLE_CONFIG } from '@/lib/roles'
import { Users, UserCheck, UserX, Crown, Clock } from 'lucide-react'
import Link from 'next/link'

interface StaffMember {
  id: string
  full_name: string
  email: string
  status: string
  created_at: string
  role: UserRole | null
}

interface Props {
  staff: StaffMember[]
  ownerName: string
}

const ROLE_COLORS: Record<string, string> = {
  owner: '#d4ab5a',
  manager: '#60a5fa',
  receptionist: '#34d399',
  housekeeping: '#a78bfa',
  security: '#f87171',
}

function KPICard({ label, value, icon, accent }: {
  label: string; value: number | string; icon: React.ReactNode; accent: string
}) {
  return (
    <div style={{
      background: '#1a1710',
      border: '1px solid #2e2b1e',
      borderRadius: '12px',
      padding: '20px 24px',
      position: 'relative',
      overflow: 'hidden',
      transition: 'border-color 0.2s',
    }}
      onMouseEnter={e => (e.currentTarget.style.borderColor = accent + '60')}
      onMouseLeave={e => (e.currentTarget.style.borderColor = '#2e2b1e')}
    >
      <div style={{
        position: 'absolute', top: 0, left: 0, right: 0, height: '2px',
        background: `linear-gradient(90deg, ${accent}, transparent)`,
      }} />
      <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between' }}>
        <div>
          <div style={{ fontSize: '11px', color: '#5c481f', letterSpacing: '0.08em', textTransform: 'uppercase', marginBottom: '8px' }}>
            {label}
          </div>
          <div style={{
            fontFamily: "'Cormorant Garamond', Georgia, serif",
            fontSize: '32px', fontWeight: 600, color: '#f4e4c1', lineHeight: 1,
          }}>
            {value}
          </div>
        </div>
        <div style={{
          width: '40px', height: '40px',
          background: `${accent}15`,
          border: `1px solid ${accent}25`,
          borderRadius: '10px',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          color: accent,
        }}>
          {icon}
        </div>
      </div>
    </div>
  )
}

export default function OwnerDashboardContent({ staff, ownerName }: Props) {
  const activeStaff = staff.filter(s => s.status === 'active')
  const inactiveStaff = staff.filter(s => s.status === 'inactive')

  const now = new Date()
  const hour = now.getHours()
  const greeting = hour < 12 ? 'Good morning' : hour < 18 ? 'Good afternoon' : 'Good evening'

  return (
    <div style={{ padding: '32px', animation: 'fadeIn 0.3s ease' }}>
      {/* Welcome */}
      <div style={{ marginBottom: '32px' }}>
        <p style={{ fontSize: '12px', color: '#5c481f', letterSpacing: '0.1em', textTransform: 'uppercase', marginBottom: '6px' }}>
          {greeting}
        </p>
        <h2 style={{
          fontFamily: "'Cormorant Garamond', Georgia, serif",
          fontSize: '32px', fontWeight: 600, color: '#f4e4c1',
        }}>
          Welcome back, {ownerName.split(' ')[0]}
        </h2>
        <p style={{ fontSize: '13px', color: '#7a6e52', marginTop: '4px' }}>
          {now.toLocaleDateString('en-GB', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
        </p>
      </div>

      {/* KPI Grid */}
      <div style={{
        display: 'grid',
        gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))',
        gap: '16px',
        marginBottom: '32px',
      }}>
        <KPICard label="Total Staff" value={staff.length} icon={<Users size={18} />} accent="#d4ab5a" />
        <KPICard label="Active Staff" value={activeStaff.length} icon={<UserCheck size={18} />} accent="#4ade80" />
        <KPICard label="Inactive" value={inactiveStaff.length} icon={<UserX size={18} />} accent="#f87171" />
        <KPICard label="Departments" value={5} icon={<Crown size={18} />} accent="#a78bfa" />
      </div>

      {/* Staff Overview */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 320px', gap: '24px' }}>
        {/* Recent Staff Table */}
        <div style={{
          background: '#1a1710',
          border: '1px solid #2e2b1e',
          borderRadius: '12px',
          overflow: 'hidden',
        }}>
          <div style={{
            padding: '16px 20px',
            borderBottom: '1px solid #2e2b1e',
            display: 'flex', alignItems: 'center', justifyContent: 'space-between',
          }}>
            <div>
              <h3 style={{ fontSize: '14px', fontWeight: 600, color: '#c4b48a' }}>Staff Overview</h3>
              <p style={{ fontSize: '11px', color: '#5c481f', marginTop: '2px' }}>{staff.length} accounts registered</p>
            </div>
            <Link href="/dashboard/users" style={{
              padding: '6px 14px',
              background: 'rgba(212,171,90,0.1)',
              border: '1px solid rgba(212,171,90,0.2)',
              borderRadius: '6px',
              fontSize: '11px',
              fontWeight: 600,
              color: '#d4ab5a',
              textDecoration: 'none',
              letterSpacing: '0.05em',
            }}>
              Manage →
            </Link>
          </div>

          {staff.length === 0 ? (
            <div style={{ padding: '48px 24px', textAlign: 'center' }}>
              <Users size={32} color="#3a3728" style={{ margin: '0 auto 12px' }} />
              <p style={{ fontSize: '14px', color: '#5c481f' }}>No staff accounts yet</p>
              <p style={{ fontSize: '12px', color: '#3a3728', marginTop: '4px' }}>Create staff accounts to get started</p>
              <Link href="/dashboard/users" style={{
                display: 'inline-flex', marginTop: '16px',
                padding: '8px 16px',
                background: 'linear-gradient(135deg, #b8923d, #d4ab5a)',
                color: '#111008', fontWeight: 600, fontSize: '12px',
                borderRadius: '6px', textDecoration: 'none',
              }}>
                Add First Staff Member
              </Link>
            </div>
          ) : (
            <div style={{ overflowX: 'auto' }}>
              <table style={{ width: '100%', borderCollapse: 'collapse' }}>
                <thead>
                  <tr style={{ background: '#221f14' }}>
                    {['Name', 'Role', 'Status', 'Joined'].map(h => (
                      <th key={h} style={{
                        padding: '10px 16px', textAlign: 'left',
                        fontSize: '10px', fontWeight: 600,
                        letterSpacing: '0.1em', textTransform: 'uppercase',
                        color: '#5c481f', borderBottom: '1px solid #2e2b1e',
                      }}>{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {staff.slice(0, 8).map(member => {
                    const roleColor = member.role ? ROLE_COLORS[member.role] : '#5c481f'
                    const roleLabel = member.role ? ROLE_CONFIG[member.role].label : 'No Role'
                    return (
                      <tr key={member.id} style={{ borderBottom: '1px solid #2e2b1e' }}
                        onMouseEnter={e => (e.currentTarget.style.background = '#221f14')}
                        onMouseLeave={e => (e.currentTarget.style.background = 'transparent')}
                      >
                        <td style={{ padding: '12px 16px' }}>
                          <div style={{ fontSize: '13px', fontWeight: 500, color: '#c4b48a' }}>
                            {member.full_name}
                          </div>
                          <div style={{ fontSize: '11px', color: '#5c481f' }}>{member.email}</div>
                        </td>
                        <td style={{ padding: '12px 16px' }}>
                          <span style={{
                            padding: '3px 10px',
                            background: `${roleColor}15`,
                            border: `1px solid ${roleColor}25`,
                            borderRadius: '100px',
                            fontSize: '11px', fontWeight: 600,
                            color: roleColor, letterSpacing: '0.04em',
                          }}>
                            {roleLabel}
                          </span>
                        </td>
                        <td style={{ padding: '12px 16px' }}>
                          <span style={{
                            display: 'inline-flex', alignItems: 'center', gap: '5px',
                            fontSize: '11px', fontWeight: 600,
                            color: member.status === 'active' ? '#4ade80' : '#f87171',
                          }}>
                            <span style={{
                              width: '6px', height: '6px', borderRadius: '50%',
                              background: member.status === 'active' ? '#4ade80' : '#f87171',
                            }} />
                            {member.status === 'active' ? 'Active' : 'Inactive'}
                          </span>
                        </td>
                        <td style={{ padding: '12px 16px', fontSize: '12px', color: '#5c481f' }}>
                          {new Date(member.created_at).toLocaleDateString('en-GB', { day: 'numeric', month: 'short' })}
                        </td>
                      </tr>
                    )
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>

        {/* Role Distribution */}
        <div style={{
          background: '#1a1710',
          border: '1px solid #2e2b1e',
          borderRadius: '12px',
          padding: '20px',
        }}>
          <div style={{ height: '2px', background: 'linear-gradient(90deg, #d4ab5a, transparent)', borderRadius: '2px', marginBottom: '20px' }} />
          <h3 style={{ fontSize: '14px', fontWeight: 600, color: '#c4b48a', marginBottom: '4px' }}>
            Staff by Role
          </h3>
          <p style={{ fontSize: '11px', color: '#5c481f', marginBottom: '20px' }}>Department breakdown</p>

          {(['manager', 'receptionist', 'housekeeping', 'security'] as UserRole[]).map(role => {
            const count = staff.filter(s => s.role === role).length
            const color = ROLE_COLORS[role]
            const label = ROLE_CONFIG[role].label
            const pct = staff.length > 0 ? (count / staff.length) * 100 : 0

            return (
              <div key={role} style={{ marginBottom: '16px' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '6px' }}>
                  <span style={{ fontSize: '12px', color: '#7a6e52' }}>{label}</span>
                  <span style={{ fontSize: '12px', fontWeight: 600, color: color }}>{count}</span>
                </div>
                <div style={{
                  height: '4px', background: '#2e2b1e', borderRadius: '2px', overflow: 'hidden',
                }}>
                  <div style={{
                    height: '100%', width: `${pct}%`,
                    background: `linear-gradient(90deg, ${color}, ${color}80)`,
                    borderRadius: '2px',
                    transition: 'width 0.6s ease',
                  }} />
                </div>
              </div>
            )
          })}

          <div style={{
            marginTop: '20px',
            padding: '12px',
            background: '#221f14',
            borderRadius: '8px',
            border: '1px solid #2e2b1e',
          }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '4px' }}>
              <Clock size={12} color="#5c481f" />
              <span style={{ fontSize: '11px', color: '#5c481f', letterSpacing: '0.06em', textTransform: 'uppercase' }}>
                More modules coming
              </span>
            </div>
            <p style={{ fontSize: '12px', color: '#3a3728' }}>
              Rooms, reservations, reports & more are being built in the next phases.
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}
