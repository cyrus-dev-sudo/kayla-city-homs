import { UserRole, ROLE_CONFIG } from '@/lib/roles'

interface TopbarProps {
  title: string
  subtitle?: string
  role: UserRole
  children?: React.ReactNode
}

const ROLE_COLORS: Record<UserRole, string> = {
  owner: '#d4ab5a',
  manager: '#60a5fa',
  receptionist: '#34d399',
  housekeeping: '#a78bfa',
  security: '#f87171',
}

export default function Topbar({ title, subtitle, role, children }: TopbarProps) {
  const roleColor = ROLE_COLORS[role]
  const roleLabel = ROLE_CONFIG[role].label

  return (
    <header style={{
      height: '60px',
      padding: '0 32px',
      borderBottom: '1px solid #2e2b1e',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      background: '#1a1710',
      position: 'sticky',
      top: 0,
      zIndex: 30,
    }}>
      <div>
        <h1 style={{
          fontFamily: "'Cormorant Garamond', Georgia, serif",
          fontSize: '18px',
          fontWeight: 600,
          color: '#f4e4c1',
          lineHeight: 1,
        }}>
          {title}
        </h1>
        {subtitle && (
          <p style={{ fontSize: '11px', color: '#5c481f', marginTop: '2px' }}>{subtitle}</p>
        )}
      </div>

      <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
        {children}
        <div style={{
          padding: '4px 12px',
          background: `${roleColor}15`,
          border: `1px solid ${roleColor}30`,
          borderRadius: '100px',
          fontSize: '11px',
          fontWeight: 600,
          color: roleColor,
          letterSpacing: '0.06em',
          textTransform: 'uppercase',
        }}>
          {roleLabel}
        </div>
      </div>
    </header>
  )
}
